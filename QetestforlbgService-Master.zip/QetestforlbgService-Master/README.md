# Qetestforlbg
Open the resources in a Eclipse (latest version - I have uses neon 3.0)
Go to help and navigate to Eclipse Marketplace Add Cucumber JVM eclipse plug-in and install it

Go to runner package and then open testRunner class Right click and navigate to Run as Junit test

Once the Test Run is complete Right click on the Halifax project and click on Refresh
Then go to the target folder and right click on index.html and select Open with - WebBrowser
This is where you will be albe to view the Test Run Results

